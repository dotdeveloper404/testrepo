<?php $__env->startSection('styles'); ?>


<style>
.copyright-text{
    display:none;
}
</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>



<!--begin::Wrapper-->
<div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
   <!--begin::Header-->

   <!--end::Header-->



   <!--begin::Content-->
   <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">





       <!--begin::Entry-->
       <div class="d-flex flex-column-fluid">
           <!--begin::Container-->
           <div class=" container ">
               <!--begin::Card-->
               <div class="card card-custom gutter-b">
                   <div class="card-body">


                   

                    <vueform></vueform>


                   

                    
                   </div>


               </div>

           </div>

       </div>
   </div>

</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\stealth\resources\views/form/create.blade.php ENDPATH**/ ?>