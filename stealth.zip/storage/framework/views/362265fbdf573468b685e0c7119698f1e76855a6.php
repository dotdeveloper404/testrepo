<?php $__env->startSection('styles'); ?>


<style>
    .copyright-text {
        display: none;
    }
</style>

<?php $__env->stopSection(); ?>


<script>
    window.formData=<?php echo $formControlData ?>
</script>



<?php $__env->startSection('content'); ?>



<!--begin::Wrapper-->
<div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
    <!--begin::Header-->

    <!--end::Header-->



    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">





        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">
                <!--begin::Card-->
                <div class="card card-custom gutter-b">
                    <div class="card-body">

                     <form id="form" action="<?php echo e(route('form.update_form_data',$form)); ?>" method="post" onkeydown="return event.key
                        !='Enter';">

                        <?php echo csrf_field(); ?>

                        <editvueform></editvueform>

                       <div class="form-group row">
                        <label class="col-lg-2 col-form-label text-right"></label>
                        <div class="col-lg-4">
                          <input  type="submit" value="Submit"  class="btn btn-primary">
                        </div>
                    </div>

                      </form>
                    </div>


                </div>

            </div>

        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\stealth\resources\views/form/get_form_data.blade.php ENDPATH**/ ?>