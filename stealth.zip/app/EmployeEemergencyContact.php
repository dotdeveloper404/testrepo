<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeEemergencyContact extends Model
{
    protected $table = 'employee_emergency_contact';

    protected $guarded = [];
}
